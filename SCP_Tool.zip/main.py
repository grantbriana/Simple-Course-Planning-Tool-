import tkinter as tk
import os
from tkinter import filedialog as fd
#import Simple_Course_Planning_Tool

#Setup Tkinter
root = tk.Tk()

#Window creation.
root.title("Simple Course Planning Tool")
canvas = tk.Canvas(root, width = 500, height = 200, bg = "#263D42")
canvas.pack()

#function for the Name Button to call when clicked.
def Submit():
    name = nameInput.get()
    showName = tk.Label(root, text = name)
    canvas.create_window(400, 100, window = showName)
    path = pathMenu.get()
    pathLabel = tk.Label(root, text = path)
    canvas.create_window(400, 150, window = pathLabel)
    root.quit()
    root.destroy()

#Textbox to type user's name into.
nameEntryLabel = tk.Label(root, text = "Enter the name of the Student", fg = "white", bg = "red")
canvas.create_window(250, 80, window = nameEntryLabel)
nameInput = tk.Entry(root)
canvas.create_window(250, 100, window = nameInput)

def degreeWorksPath():
    filePath = tk.StringVar()
    filename = fd.askopenfilename()
    filePath.set(filename)

#Button to submit input'
degreeWorksButton = tk.Button(root, text ="DegreeWorks Path", padx=10, pady = 4, fg ="white", bg ="blue", command = degreeWorksPath)
submitButton = tk.Button(root, text ="Submit", padx=15, pady = 9, fg ="white", bg ="blue", command = Submit)
submitButton.pack()
degreeWorksButton.pack()


#drop menu for selecting a path.
pathMenu = tk.StringVar()
pathMenu.set("Select your degree track:")
drop = tk.OptionMenu(root, pathMenu, "Software Systems", "Game Development", "Network Security", "Education", "Web Development", "Enterprise")
drop.pack()

def degreeWorksPath():
    filePath = tk.StringVar()
    filename = fd.askopenfilename()
    filePath.set(filename)
    canvas.create_window(250, 120, window = filePath)



root.mainloop()

import pandas
import csv
import networkx as nx
from matplotlib import pyplot as plt
import numpy as np
from networkx.drawing.nx_pydot import graphviz_layout

pathLine = pathMenu.get()
endPath = ""
courses = []


class course:
    def __init__(self, name, description, hours, fall, spring, summer, prereq, taken):
        # string
        self.name = str(name)
        # string
        self.description = str(description)
        # int
        self.hours = int(hours)
        # bool
        self.fall = True if fall == "TRUE" else False
        # bool
        self.spring = True if spring == "TRUE" else False
        # bool
        self.summer = True if summer == "TRUE" else False
        # dict
        self.prereq = str(prereq)
        # bool
        self.taken = True if taken == "TRUE" else False

    # Created these functions to grab the information.
    def __str__(
            self):  # ----->This is a string. This will output all the info for a class. ex use / print(course[0])  or print(course[0].Name() for specific info
        return f'{self.name}, {self.description}, {self.hours}, {"Fall"},{self.fall},{"Spring"}, {self.spring}, {"Summer"},{self.summer}, {self.prereq}, {self.taken}'

    def Name(self):
        return self.name

    def Description(self):
        return self.description

    def Hours(self):
        return self.hours

    def Fall(self):
        return self.fall

    def Spring(self):
        return self.spring

    def Summer(self):
        return self.summer

    def Prereq(self):
        return self.prereq

    def Taken(self):
        return self.taken

def getUserTrack(drop):
    match drop:
        #software systems
        case "Software Systems":
            course_requirements = "Q:\SCP tool\Software Systems Track.csv"
            populateCourseArray(course_requirements)
        #education
        case "Education":
            course_requirements = "Tracks/Education Track - Sheet1.csv"
            populateCourseArray(course_requirements)
        #cybersecurity
        case "Network Security":
            course_requirements = "Tracks/Cybersecurity Track - Sheet1.csv"
            populateCourseArray(course_requirements)
        #games programming
        case "Game Development":
            course_requirements = "Tracks/Games Programming Track - Sheet1 (1).csv"
            populateCourseArray(course_requirements)
        #web development
        case "Web Development":
            course_requirements = "web development track.csv"
            populateCourseArray(course_requirements)
        #Enterprise
        case "Enterprise":
            course_requirements = "Tracks/Enterprise Computing Track - Sheet1.csv"
            populateCourseArray(course_requirements)


def populateCourseArray(path):
    with open(path, mode='r', encoding='utf-8-sig') as csvfile:
        datareader = csv.reader(csvfile)
        for row in datareader:
            newCourse = course(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
            courses.append(newCourse)


getUserTrack(pathLine)

print(len(courses))


#-------------------------Schedule Constructor____________________________
tempArray = []
courseArray = []
classesArrayStage = []
Working = True

for i in courses:
    classesArrayStage.append(i)
#checks if courses prereq has been taken
def prereqCheck(course):
    if course.prereq != "":
        istaken = False
        for course2 in courses:
            if (course.prereq == course2.name) and course2.taken == True:
                istaken = True
        return istaken
    else:
        return False
#builds each semester based on if it is during the
def scheduleCreate():
    while Working:
        tempArray = []
        j = 0
        for course in courses:
            if(j < 12):
                if course.spring == True:
                    if (course.taken == False):
                        if tempArray:
                            isAPrereq = False
                            for i in tempArray:
                                if i.name == course.prereq:
                                    isAPrereq = True
                                else:
                                    isAPrereq = False
                            if ((isAPrereq == False and prereqCheck(course) == True) or course.prereq ==""):
                                tempArray.append(course)
                                j = j + course.hours
                        elif not tempArray:
                            tempArray.append(course)
                            j = j + course.hours

                #else:

        if(not tempArray):
            break
        courseArray.append(tempArray)
        for i in tempArray:
            i.taken = True

        tempArray = []
        j = 0
        for course in courses:
            if(j < 12):
                if course.summer == True:
                    if (course.taken == False):
                        if tempArray:
                            isAPrereq = False
                            for i in tempArray:
                                if i.name == course.prereq:
                                    isAPrereq = True
                                else:
                                    isAPrereq = False
                            if ((isAPrereq == False and prereqCheck(course) == True) or course.prereq ==""):
                                tempArray.append(course)
                                j = j + course.hours
                        elif not tempArray:
                            tempArray.append(course)
                            j = j + course.hours

                #else:

        if(not tempArray):
            break
        courseArray.append(tempArray)
        for i in tempArray:
            i.taken = True

        tempArray = []
        j = 0
        for course in courses:
            if(j < 12):
                if course.fall == True:
                    if (course.taken == False):
                        if tempArray:
                            isAPrereq = False
                            for i in tempArray:
                                if i.name == course.prereq:
                                    isAPrereq = True
                                else:
                                    isAPrereq = False
                            if ((isAPrereq == False and prereqCheck(course) == True) or course.prereq ==""):
                                tempArray.append(course)
                                j = j + course.hours
                        elif not tempArray:
                            tempArray.append(course)
                            j = j + course.hours

                #else:

        if(not tempArray):
            break
        courseArray.append(tempArray)
        for i in tempArray:
            i.taken = True
#calls the function
scheduleCreate()

#out the classes. For testing purposes
k = 1
def season():
    if k in (1, 4, 7):
        return "Spring"
    elif k in (2, 5, 8):
        return  "Summer"
    elif k in (3, 6, 9):
        return  "Fall"
for course in courseArray:
    print("\n" + "Semester: " + str(k) + " " + season() + "\n")
    k = k + 1
    for i in course:
        print(i)
#------------------------------------------------------------DAG tree
# group nodes by column
left_nodes = []
middle_nodes = []
right_nodes = []

graph = nx.DiGraph()
graph.add_node("Senior")
graph.add_node("Senior/Junior")

for course in courses:
    graph.add_node(str(course.name))
j = 0
for classes in courses:
    for classes2 in courses:
        if classes2.prereq == classes.name:
            graph.add_edge(classes.name, classes2.name)
        elif classes.prereq == "Senior":
            graph.add_edge(classes.name, "Senior")
        elif classes.prereq == "Senior/Junior":
            graph.add_edge(classes.name, "Senior")
            graph.add_edge(classes.name, "Senior/Junior")
for classes in courses:
    if graph.nodes(classes):
        graph.add_node(classes.name)


for classes in courses:
    if classes.prereq == "":
        left_nodes.append(classes.name)
    else:
        for classes2 in courses:
            if classes.prereq != "" and classes.name == classes2.prereq:
                middle_nodes.append(classes.name)
            elif classes.prereq != "" and classes.name != classes2.prereq:
                right_nodes.append(classes)

# pos = nx.DiGraph({n: (0, i) for i, n in enumerate(left_nodes)})
# pos.update({n: (1, i + 0.5) for i, n in enumerate(middle_nodes)})
# pos.update({n: (2, i + 0.5) for i, n in enumerate(right_nodes)})

plt.figure(1,figsize=(12,12))
print(len(graph.nodes()))
d = dict(graph.degree)
list(nx.topological_sort(graph))
plt.tight_layout()
nx.draw(graph, with_labels=True,font_weight='bold', node_size=500)
ax = plt.gca()
ax.margins(0.01)
plt.axis("off")
plt.savefig("DAG.png")
plt.show()
i = 0;
list(reversed(list(nx.topological_sort(graph))))
graph.edges()

import xlwt
j =0
from xlwt import Workbook
wb = Workbook()
sheet1 = wb.add_sheet('Sheet 1')
for i in courseArray:
    for k in i:
        sheet1.write(j, 0, k.name)
        sheet1.write(j, 1, k.description)
        sheet1.write(j, 2, str(k.hours))
        sheet1.write(j, 3, k.prereq)
        j = j + 1
    j = j + 1

wb.save('SCP_Tool_output.xls')

